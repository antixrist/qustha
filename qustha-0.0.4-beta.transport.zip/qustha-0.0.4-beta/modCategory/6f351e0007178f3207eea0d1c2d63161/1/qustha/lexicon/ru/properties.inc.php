<?php

$_lang['qustha_prop_type'] = 'Тип переменных для показа.';
$_lang['qustha_prop_tpl'] = 'Имя чанка для оформления.';
$_lang['qustha_prop_tplWrapper'] = 'Имя чанка-обёртки.';
$_lang['qustha_prop_wrapIfEmpty'] = 'Включает вывод чанка-обертки (tplWrapper) даже если результатов нет.';
$_lang['qustha_prop_outputSeparator'] = 'Необязательная строка для разделения результатов работы.';

