<?php
$qustha = $modx->getService('qustha','qustha',$modx->getOption('qustha_core_path',null,$modx->getOption('core_path').'components/qustha/').'model/qustha/',$scriptProperties);
if (!($qustha instanceof qustha)) return '';

$arr = $qustha->getFIHookVarsValues();
$hook->setValues($arr);
return true;