--------------------
qustha
--------------------
Author: antixrist <ya@antixrist.ru>
--------------------

A basic Extra for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/antixrist/qustha/issues